%% Set parameter values
R = 0.06;
r = 0.3;
Tr = 5;
Tf = 0.05;
Tg = 0.2;
Tw = 1;
At = 1;
qnl = 0.1;
Dt=0;%.5;

H = 3.5;
Kd = 0.1;